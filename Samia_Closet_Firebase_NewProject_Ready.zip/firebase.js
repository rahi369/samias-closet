import { initializeApp } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithRedirect, getRedirectResult, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js";
import { getFirestore, collection, getDocs, getDoc, doc, addDoc, setDoc, updateDoc, deleteDoc, query, orderBy, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL, deleteObject } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-storage.js";
import { firebaseConfig, ADMIN_EMAIL, STORE_DEFAULTS } from "./firebase-config.js";

export const firebaseReady = !Object.values(firebaseConfig).some(v => String(v).startsWith("YOUR_"));
export const app = firebaseReady ? initializeApp(firebaseConfig) : null;
export const auth = app ? getAuth(app) : null;
export const db = app ? getFirestore(app) : null;
export const storage = app ? getStorage(app) : null;
export const googleProvider = new GoogleAuthProvider();

export function isAdminUser(user){
  return !!user && user.email && user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase();
}

export async function adminLogin(){
  if(!firebaseReady) throw new Error("Firebase is not configured yet.");
  await signInWithRedirect(auth, googleProvider);
}

export async function finishRedirect(){
  if(!firebaseReady) return null;
  try { return await getRedirectResult(auth); } catch(e){ console.warn(e); return null; }
}

export function watchAuth(cb){
  if(!firebaseReady) { cb(null); return () => {}; }
  return onAuthStateChanged(auth, cb);
}

export async function adminLogout(){ if(auth) await signOut(auth); }

export async function getSettings(){
  if(!firebaseReady) return {...STORE_DEFAULTS};
  const snap = await getDoc(doc(db,"settings","site"));
  return snap.exists() ? {...STORE_DEFAULTS, ...snap.data()} : {...STORE_DEFAULTS};
}

export async function saveSettings(data){
  await setDoc(doc(db,"settings","site"), {...data, updatedAt: serverTimestamp()}, {merge:true});
}

export async function listProducts(){
  if(!firebaseReady) return [];
  const snap = await getDocs(collection(db,"products"));
  return snap.docs.map(d=>({id:d.id,...d.data()}));
}

export async function saveProduct(product, id=null){
  const clean = {...product, updatedAt: serverTimestamp()};
  if(id) await updateDoc(doc(db,"products",id),clean);
  else { clean.createdAt = serverTimestamp(); await addDoc(collection(db,"products"),clean); }
}

export async function removeProduct(id){ await deleteDoc(doc(db,"products",id)); }

export async function uploadImage(file, folder="products"){
  if(!file) throw new Error("No image selected.");
  const safe = file.name.replace(/[^a-zA-Z0-9._-]/g,"-");
  const path = `${folder}/${Date.now()}-${safe}`;
  const storageRef = ref(storage,path);
  await uploadBytes(storageRef,file,{contentType:file.type || "image/jpeg"});
  return {url: await getDownloadURL(storageRef), path};
}

export async function listOrders(){
  if(!firebaseReady) return [];
  const snap = await getDocs(query(collection(db,"orders"),orderBy("createdAt","desc")));
  return snap.docs.map(d=>({id:d.id,...d.data()}));
}

export async function createOrder(order){
  await addDoc(collection(db,"orders"),{...order,status:"New",createdAt:serverTimestamp()});
}

export async function updateOrder(id,status){ await updateDoc(doc(db,"orders",id),{status,updatedAt:serverTimestamp()}); }

export { deleteObject };
