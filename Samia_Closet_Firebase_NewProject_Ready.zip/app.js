const KEY="samia_v2";
const defaults={
 settings:{wa:"8801314652599",pagePhone:"01852523494",facebook:"https://www.facebook.com/share/1DxQzbBqLc/",tiktok:"https://www.tiktok.com/@shop.with.samia",instagram:"https://www.instagram.com/shop.with.samia/",about:"Thoughtfully selected premium fashion for everyday elegance.",delivery:"Questions about size, delivery or an order? We're one message away."},
 products:[
  {id:1,name:"Elegant Dress",cat:"Dress",price:450,img:""},
  {id:2,name:"Premium Three Piece",cat:"Three Piece",price:550,img:""},
  {id:3,name:"Everyday Collection",cat:"Dress",price:400,img:""},
  {id:4,name:"New Arrival",cat:"New",price:650,img:""}
 ],
 orders:[]
};
let data;
try{data=JSON.parse(localStorage.getItem(KEY)||"null")}catch(e){data=null}
if(!data||!Array.isArray(data.products)) data=defaults;
if(!data.settings) data.settings=defaults.settings;
if(!Array.isArray(data.orders)) data.orders=[];
let cart=[],cat="All";

function save(){localStorage.setItem(KEY,JSON.stringify(data))}
function product(p){
 return `<article class="card">
  <div class="pic">${p.img?`<img src="${p.img}" alt="${escapeHtml(p.name)}">`:`<div class="placeholder">Samia's Closet</div>`}</div>
  <div class="card-info"><small>${escapeHtml(p.cat||"COLLECTION")}</small><h3>${escapeHtml(p.name)}</h3>
  <div class="row"><b class="price">৳${Number(p.price)||0}</b><button class="add" onclick="add(${p.id})">ADD +</button></div></div>
 </article>`
}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function render(){
 const q=(document.getElementById("search")?.value||"").toLowerCase();
 const list=data.products.filter(p=>(cat==="All"||p.cat===cat)&&String(p.name).toLowerCase().includes(q));
 document.getElementById("products").innerHTML=list.length?list.map(product).join(""):'<div class="empty">Collection coming soon.</div>';
 document.getElementById("newProducts").innerHTML=data.products.slice(0,4).map(product).join("");
}
function setCat(c){cat=c;render()}
function add(id){const p=data.products.find(x=>x.id===id);if(p){cart.push(p);document.getElementById("count").textContent=cart.length}}
function openCart(){renderCart();document.getElementById("drawer").classList.add("open");document.getElementById("shade").classList.add("open")}
function closeCart(){document.getElementById("drawer").classList.remove("open");document.getElementById("shade").classList.remove("open")}
function renderCart(){
 const e=document.getElementById("cartItems");
 e.innerHTML=cart.length?cart.map((p,i)=>`<div class="cart-item"><span>${escapeHtml(p.name)}</span><b>৳${p.price} <button onclick="cart.splice(${i},1);renderCart();document.getElementById('count').textContent=cart.length">×</button></b></div>`).join(""):'<div class="empty">Your bag is empty.</div>';
 document.getElementById("total").textContent=cart.reduce((a,p)=>a+Number(p.price||0),0);
}
function checkout(){if(!cart.length)return alert("আপনার bag খালি।");document.getElementById("checkout").classList.add("show")}
function closeCheckout(){document.getElementById("checkout").classList.remove("show")}
function placeOrder(){
 const n=document.getElementById("name").value.trim(),ph=document.getElementById("phone").value.trim(),ad=document.getElementById("address").value.trim();
 if(!n||!ph||!ad)return alert("সব তথ্য পূরণ করুন");
 data.orders.push({id:Date.now(),name:n,phone:ph,address:ad,items:cart.map(x=>x.name),total:cart.reduce((a,p)=>a+Number(p.price||0),0),status:"Pending"});
 save();alert("অর্ডার গ্রহণ করা হয়েছে ❤️");cart=[];document.getElementById("count").textContent=0;closeCheckout();closeCart();
}
function focusSearch(){location.hash="collection";setTimeout(()=>document.getElementById("search").focus(),250)}
document.getElementById("year").textContent=new Date().getFullYear();
document.getElementById("wa").href="https://wa.me/"+data.settings.wa;
document.getElementById("fb").href=data.settings.facebook;document.getElementById("tt").href=data.settings.tiktok;document.getElementById("ig").href=data.settings.instagram;
if(document.getElementById("aboutText"))document.getElementById("aboutText").textContent=data.settings.about||defaults.settings.about;
if(document.getElementById("deliveryText"))document.getElementById("deliveryText").textContent=data.settings.delivery||defaults.settings.delivery;
render();