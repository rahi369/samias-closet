// Samia's Closet — Firebase Web App configuration
export const firebaseConfig = {
  apiKey: "AIzaSyBI_7ctv3PGoaknMt2e9Z4o_TKB_fSgxik",
  authDomain: "samia-s-closet-1aac1.firebaseapp.com",
  projectId: "samia-s-closet-1aac1",
  storageBucket: "samia-s-closet-1aac1.firebasestorage.app",
  messagingSenderId: "912430030937",
  appId: "1:912430030937:web:b605929a2caa38dc4e9148",
  measurementId: "G-QLJDZ9YB2W"
};

export const ADMIN_EMAIL = "aminulhasim73@gmail.com";

export const STORE_DEFAULTS = {
  storeName: "Samia’s Closet",
  tagline: "Curated fashion. Made to feel like you.",
  heroTitle: "STYLE THAT FEELS LIKE YOU",
  heroSubtitle: "Discover carefully selected premium fashion with a premium feel.",
  heroButton: "SHOP NEW ARRIVALS",
  whatsapp: "01834012069",
  ownerName: "Md.Humaun Husen Rahi",
  contactLabel: "DIRECT CONTACT WITH RAHI",
  facebook: "https://www.facebook.com/share/1DxQzbBqLc/",
  tiktok: "https://www.tiktok.com/@shop.with.samia?_r=1&_t=ZS-9A8d6CHf0a6",
  instagram: "https://www.instagram.com/shop.with.samia?stkn=MWVtem5jdzJoNnpyMw==",
  about: "Samia’s Closet brings together carefully selected fashion for women and boys/men, with a premium shopping experience.",
  deliveryText: "Fast delivery and friendly support across Bangladesh."
};
